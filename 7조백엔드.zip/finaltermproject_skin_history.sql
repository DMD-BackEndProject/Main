-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: finaltermproject
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `skin_history`
--

DROP TABLE IF EXISTS `skin_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skin_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` varchar(50) NOT NULL,
  `wrinkle` int NOT NULL,
  `pore` int NOT NULL,
  `redness` int NOT NULL,
  `oil` int NOT NULL,
  `tone` int NOT NULL,
  `skinType` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skin_history`
--

LOCK TABLES `skin_history` WRITE;
/*!40000 ALTER TABLE `skin_history` DISABLE KEYS */;
INSERT INTO `skin_history` VALUES (1,'juntak4607',26,1,72,24,76,'건성','2025-12-02 13:30:05'),(2,'juntak4607',38,88,85,62,86,'지성','2025-12-02 13:32:23'),(3,'juntak4607',28,96,91,23,71,'지성','2025-12-02 13:34:22'),(4,'juntak4607',89,97,98,76,0,'지성','2025-12-02 13:39:55'),(5,'juntak4607',70,10,15,41,14,'건성','2025-12-02 14:09:50'),(6,'juntak4607',74,46,76,71,24,'지성','2025-12-02 15:02:12'),(7,'juntak4607',28,53,26,51,24,'정상','2025-12-02 15:06:32'),(8,'juntak4607',91,55,72,13,43,'건성','2025-12-02 15:06:55'),(9,'juntak4607',19,43,32,1,94,'건성','2025-12-02 15:17:08'),(10,'juntak4607',52,60,74,94,6,'지성','2025-12-02 15:19:03');
/*!40000 ALTER TABLE `skin_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03  0:26:06
