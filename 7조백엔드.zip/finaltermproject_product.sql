-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: finaltermproject
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `skin_type` varchar(20) DEFAULT NULL,
  `image_url` varchar(300) DEFAULT NULL,
  `info` text,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'퓨어 클렌징 오일','클렌저','건성','/img/cleanser1.jpg','돌콩에서 추출한 도톰하고 밀도있는 오일로 딥클렌징'),(2,'녹두 약산성 클렌징폼','클렌저','지성','/img/cleanser2.jpg','녹두로 채우는 모공 자신감 피지까지 말끔 모공'),(3,'녹두 클렌징 오일','클렌저','복합성','/img/cleanser3.jpg','모공 막힘 걱정 없는 블랙헤드 쏙오프'),(4,'다시마 앰플 클렌징폼','클렌저','민감성','/img/cleanser4.jpg','청정해역 다시마가 품은 수분 진정 성분'),(5,'세이프 미 릴리프 모이스처 클렌징 밀크','클렌저','정상','/img/cleanser5.jpg','수분 지키는 저자극 클렌징 밀크'),(6,'아쿠아 오아시스 토너','토너','건성','/img/toner1.jpg','촉촉 진정 수분광 토너'),(7,'다이브인 저분자 히알루론산 토너','토너','지성','/img/toner2.jpg','첫 단계 산뜻 수분 충전 수분결 토너'),(8,'원더 세라마이드 모찌 토너','토너','복합성','/img/toner3.jpg','보습부터 케어까지 원샷 원킬 토너'),(9,'1025 독도 토너','토너','민감성','/img/toner4.jpg','자극없는 순한 케어 국민 토너'),(10,'캐롯 카로틴 카밍 워터 패드','토너','정상','/img/toner5.jpg','진정한 당근의 힘으로 수분듬뿍, 당근진정'),(11,'PDRN 히알루론산 캡슐 100 세럼','세럼','건성','/img/serum1.jpg','피부 속부터 차오르는 광채 플럼핑 세럼'),(12,'다이브인 저분자 히알루론산 세럼','세럼','지성','/img/serum2.jpg','48시간 지속 3중 수분 케어'),(13,'데일리 컨셔스 세럼','세럼','복합성','/img/serum3.jpg','속부터 차오르는 고보습 집중 세럼'),(14,'아쿠아 스쿠알란 세럼','세럼','민감성','/img/serum4.jpg','속수분충전 & 모공 탄력까지, 수분천재세럼'),(15,'피디알엔 모공 탄력 세럼','세럼','정상','/img/serum5.jpg','세럼 한 병에 가득 채운 모공 & 탄력 솔루션'),(16,'모이스춰 닥터 크림','크림','건성','/img/cream1.jpg','속보습 100시간 장수진 수분크림'),(17,'다이브인 저분자 히알루론산 수딩 크림','크림','지성','/img/cream2.jpg','수분충전부터 열감진정까지'),(18,'녹두 모공 타이트업 수딩 크림','크림','복합성','/img/cream3.jpg','모공 열 잡고 속 탄력 끌올'),(19,'아토베리어365 크림','크림','민감성','/img/cream4.jpg','민감 피부에 특화된 고밀도 세라마이드'),(20,'아쿠아 스쿠알란 수분크림','크림','정상','/img/cream5.jpg','피지, 모공 싹싹 촉촉함만 남기는 크림');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03  0:26:06
