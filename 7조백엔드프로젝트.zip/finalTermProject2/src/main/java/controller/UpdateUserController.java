package controller;

import dao.UserDAO;
import dto.UserDTO;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/updateUser")
public class UpdateUserController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        UserDTO dto = new UserDTO();
        dto.setUserId(req.getParameter("user_id"));
        dto.setUserName(req.getParameter("user_name"));
        dto.setUserPw(req.getParameter("user_pw"));

        UserDAO dao = new UserDAO();
        int result = dao.updateUser(dto);

        if (result > 0) {
            // 세션 업데이트
            req.getSession().setAttribute("user", dto);
            resp.sendRedirect("mypage");
        } else {
            resp.sendRedirect("error.jsp");
        }
    }
}
