package controller;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@WebServlet("/faceAnalyze")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 1,   // 1MB 메모리 임계값
        maxFileSize = 1024 * 1024 * 10,       // 10MB 업로드 파일 제한
        maxRequestSize = 1024 * 1024 * 20     // 20MB 요청 제한
)
public class FaceAnalysisController extends HttpServlet {

    // TODO 👉 여기 Face++ API key/secret 입력
    private static final String API_KEY = "KQlW1nKQL6fSQ8cVOLInxOjJZRdhuH0K";
    private static final String API_SECRET = "24Hl1uhYvfD62xn2BEl3SSOH1W9_nPjs";

    // Face++ 피부 분석 API URL
    private static final String API_URL =
            "https://api-us.faceplusplus.com/facepp/v3/face/analyze";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=UTF-8");

        Part filePart = request.getPart("faceImage");

        if (filePart == null || filePart.getSize() == 0) {
            response.getWriter().write("{\"error\":\"이미지가 비어있습니다.\"}");
            return;
        }

        // 이미지 → InputStream
        InputStream imgStream = filePart.getInputStream();

        // Face++ API로 요청 보내기
        JsonObject apiResult = callFacePlusPlus(imgStream);

        if (apiResult == null) {
            response.getWriter().write("{\"error\":\"Face++ API 오류\"}");
            return;
        }

        // 결과 파싱
        JsonObject parsed = parseResult(apiResult);

        // JSON 응답
        response.getWriter().write(parsed.toString());
    }

    /** ==============================
     *  Face++ API 호출 (POST multipart/form-data)
     *  ============================== */
    private JsonObject callFacePlusPlus(InputStream imgStream) {

        try {
            // URL 연결
            URL url = new URL(API_URL + "?return_landmark=1&return_attributes=skinstatus");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            String boundary = "----WebKitFormBoundary" + System.currentTimeMillis();

            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            DataOutputStream dos = new DataOutputStream(conn.getOutputStream());

            // API KEY
            dos.writeBytes("--" + boundary + "\r\n");
            dos.writeBytes("Content-Disposition: form-data; name=\"api_key\"\r\n\r\n");
            dos.writeBytes(API_KEY + "\r\n");

            // API SECRET
            dos.writeBytes("--" + boundary + "\r\n");
            dos.writeBytes("Content-Disposition: form-data; name=\"api_secret\"\r\n\r\n");
            dos.writeBytes(API_SECRET + "\r\n");

            // 이미지 파일
            dos.writeBytes("--" + boundary + "\r\n");
            dos.writeBytes("Content-Disposition: form-data; name=\"image_file\"; filename=\"face.jpg\"\r\n");
            dos.writeBytes("Content-Type: application/octet-stream\r\n\r\n");

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = imgStream.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }
            dos.writeBytes("\r\n");

            dos.writeBytes("--" + boundary + "--\r\n");
            dos.flush();
            dos.close();

            // 응답 읽기
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();

            return JsonParser.parseString(sb.toString()).getAsJsonObject();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /** ==============================
     *  Face++ 결과 → UI에서 사용하기 쉽게 변환
     *  ============================== */
    private JsonObject parseResult(JsonObject apiJson) {

        JsonObject result = new JsonObject();

        try {
            JsonObject face = apiJson.getAsJsonArray("faces").get(0).getAsJsonObject();
            JsonObject attr = face.getAsJsonObject("attributes");
            JsonObject skin = attr.getAsJsonObject("skinstatus");

            // Face++ 제공 정보 예시
            double darkCircle = skin.get("dark_circle").getAsDouble();
            double stain      = skin.get("stain").getAsDouble();
            double acne       = skin.get("acne").getAsDouble();
            double blackhead  = skin.get("blackhead").getAsDouble();
            double pore       = skin.get("pore").getAsDouble();

            // 간단한 로직 → 피부 타입 판단
            String skinType = "일반 피부";
            if (pore > 50 || blackhead > 50) skinType = "지성 피부";
            if (stain > 55 || acne > 55)     skinType = "트러블 피부";
            if (darkCircle > 60)             skinType = "피곤함/수분 부족";

            // JSON으로 정리
            result.addProperty("skinType", skinType);
            result.addProperty("oil", pore);
            result.addProperty("moisture", 100 - stain);
            result.addProperty("sensitivity", acne);

            // 태그
            List<String> tags = new ArrayList<>();
            if (pore > 50) tags.add("모공 고민");
            if (acne > 50) tags.add("트러블 경향");
            if (stain > 50) tags.add("톤 불균형");

            result.add("tags", toJsonArray(tags));

            // 추천 루틴
            JsonObject r1 = new JsonObject();
            r1.addProperty("title", "🌞 아침 루틴");
            r1.addProperty("desc", "젤 클렌저 → 수분 토너 → 가벼운 수분크림 → 무기자차");

            JsonObject r2 = new JsonObject();
            r2.addProperty("title", "🌙 저녁 루틴");
            r2.addProperty("desc", "약산성 클렌저 → 진정 토너 → 세럼 → 보습크림");

            result.add("routine", toJsonArray(Arrays.asList(r1, r2)));

        } catch (Exception e) {
            result.addProperty("error", "분석 중 오류 발생");
        }

        return result;
    }

    /** List → JsonArray 변환 */
    private com.google.gson.JsonArray toJsonArray(List<?> list) {
        com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
        for (Object o : list) {
            if (o instanceof String)
                arr.add(o.toString());
            else
                arr.add((JsonObject) o);
        }
        return arr;
    }
}
