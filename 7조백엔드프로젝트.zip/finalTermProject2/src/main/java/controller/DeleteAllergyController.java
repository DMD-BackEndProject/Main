package controller;

import dao.UserDAO;
import dto.UserDTO;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/deleteAllergy")
public class DeleteAllergyController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String ingredient = req.getParameter("ingredient");
        UserDTO user = (UserDTO) req.getSession().getAttribute("user");

        UserDAO dao = new UserDAO();
        dao.deleteAllergy(user.getUserId(), ingredient);

        resp.sendRedirect("mypage");  // 다시 마이페이지로 이동
    }
}
