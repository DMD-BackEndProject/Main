package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDAO;
import dto.UserDTO;

@WebServlet("/mypage")
public class MyPageController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        if (user == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        UserDAO dao = new UserDAO();

        // 최근 로그 3개
        List<String> history = dao.getRecentHistory(user.getUserId());
        req.setAttribute("history", history);

        // 추천 목록 (skinType이 필요함 → skin_log에서 가장 최근 skin_type 사용)
        String skinType = null;
        if (!history.isEmpty()) {
            skinType = history.get(0).split(" : ")[1];
        }

        req.setAttribute("skinType", skinType);

        // 알레르기 성분
        List<String> allergy = dao.getAllergy(user.getUserId());
        req.setAttribute("allergy", allergy);

        req.getRequestDispatcher("mypage.jsp").forward(req, resp);
    }
}

