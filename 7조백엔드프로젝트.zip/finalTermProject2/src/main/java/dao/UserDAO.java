package dao;

import dto.UserDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    private final String URL = "jdbc:mysql://localhost:3306/finaltermproject?serverTimezone=UTC";
    private final String USER = "root";
    private final String PASSWORD = "1234";

    // DB 연결
    private void getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // DB 자원 정리
    private void close() {
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✔ 로그인 기능
    public UserDTO login(String id, String pw) {
        UserDTO user = null;

        String sql = "SELECT * FROM user WHERE user_id=? AND user_pw=?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            pstmt.setString(2, pw);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                user = new UserDTO();
                user.setUserId(rs.getString("user_id"));
                user.setUserPw(rs.getString("user_pw"));
                user.setUserName(rs.getString("user_name"));
                user.setRole(rs.getString("role"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return user;
    }

    // ✔ 회원가입 기능
    public int signup(UserDTO dto) {
        int result = 0;

        String sql = "INSERT INTO user(user_id, user_pw, user_name, role) VALUES (?, ?, ?, 'USER')";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dto.getUserId());
            pstmt.setString(2, dto.getUserPw());
            pstmt.setString(3, dto.getUserName());

            result = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return result;
    }

    // ✔ 전체 회원 조회 (관리자용)
    public List<UserDTO> getAllUsers() {
        List<UserDTO> list = new ArrayList<>();

        String sql = "SELECT user_id, user_pw, user_name, role FROM user";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                UserDTO dto = new UserDTO();
                dto.setUserId(rs.getString("user_id"));
                dto.setUserPw(rs.getString("user_pw"));
                dto.setUserName(rs.getString("user_name"));
                dto.setRole(rs.getString("role"));
                list.add(dto);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return list;
    }

    // ✔ 특정 회원 조회
    public UserDTO getUserInfo(String id) {
        UserDTO dto = null;

        String sql = "SELECT * FROM user WHERE user_id=?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                dto = new UserDTO();
                dto.setUserId(rs.getString("user_id"));
                dto.setUserPw(rs.getString("user_pw"));
                dto.setUserName(rs.getString("user_name"));
                dto.setRole(rs.getString("role"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return dto;
    }

    // ✔ 회원정보 수정 기능 (필요 시)
    public int updateUser(UserDTO dto) {
        int result = 0;

        String sql = "UPDATE user SET user_pw=?, user_name=? WHERE user_id=?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dto.getUserPw());
            pstmt.setString(2, dto.getUserName());
            pstmt.setString(3, dto.getUserId());

            result = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return result;
    }

    // ✔ 회원 삭제 기능 (관리자용)
    public int deleteUser(String id) {
        int result = 0;

        String sql = "DELETE FROM user WHERE user_id=?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);

            result = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return result;
    }
    public List<UserDTO> searchUsers(String keyword) {
        List<UserDTO> list = new ArrayList<>();

        String sql = "SELECT * FROM user WHERE user_id LIKE ? OR user_name LIKE ?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            rs = pstmt.executeQuery();

            while (rs.next()) {
                UserDTO dto = new UserDTO();
                dto.setUserId(rs.getString("user_id"));
                dto.setUserPw(rs.getString("user_pw"));
                dto.setUserName(rs.getString("user_name"));
                dto.setRole(rs.getString("role"));
                list.add(dto);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return list;
    }
    
    public List<String> getRecentHistory(String userId) {
        List<String> list = new ArrayList<>();

        String sql = "SELECT skin_type, created_at FROM skin_log WHERE user_id=? ORDER BY created_at DESC LIMIT 3";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                String item = rs.getTimestamp("created_at").toString().substring(0, 10)
                        + " : " + rs.getString("skin_type");
                list.add(item);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return list;
    }
    
    public List<String> getAllergy(String userId) {
        List<String> list = new ArrayList<>();

        String sql = "SELECT ingredient FROM user_allergy WHERE user_id=?";
        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                list.add(rs.getString("ingredient"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return list;
    }

    public List<UserDTO> getRecommend(String skinType) {
        List<UserDTO> list = new ArrayList<>();

        String sql = "SELECT * FROM product_recommend WHERE skin_type=?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, skinType);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                UserDTO dto = new UserDTO();
                dto.setUserName(rs.getString("brand"));     // 임시: brand
                dto.setUserPw(rs.getString("product_name")); // 임시: product
                dto.setRole(rs.getString("reason"));         // 임시: reason
                list.add(dto);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return list;
    }
    
    public int addAllergy(String userId, String ingredient) {
        int result = 0;

        String sql = "INSERT INTO user_allergy(user_id, ingredient) VALUES(?, ?)";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);
            pstmt.setString(2, ingredient);

            result = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
        return result;
    }

    public int deleteAllergy(String userId, String ingredient) {
        int result = 0;

        String sql = "DELETE FROM user_allergy WHERE user_id=? AND ingredient=?";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);
            pstmt.setString(2, ingredient);

            result = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return result;
    }

    public List<UserDTO> getUsersOrderByLatest() {
        List<UserDTO> list = new ArrayList<>();

        String sql = "SELECT * FROM user ORDER BY created_at DESC";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                UserDTO dto = new UserDTO();
                dto.setUserId(rs.getString("user_id"));
                dto.setUserName(rs.getString("user_name"));
                dto.setUserPw(rs.getString("user_pw"));
                dto.setRole(rs.getString("role"));
                list.add(dto);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return list;
    }

    public List<UserDTO> getUsersOrderByName() {
        List<UserDTO> list = new ArrayList<>();

        String sql = "SELECT * FROM user ORDER BY user_name ASC";

        try {
            getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                UserDTO dto = new UserDTO();
                dto.setUserId(rs.getString("user_id"));
                dto.setUserName(rs.getString("user_name"));
                dto.setUserPw(rs.getString("user_pw"));
                dto.setRole(rs.getString("role"));
                list.add(dto);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }

        return list;
    }


}
